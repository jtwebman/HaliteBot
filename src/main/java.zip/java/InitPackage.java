class InitPackage {
    int myID;
    GameMap map;
}
