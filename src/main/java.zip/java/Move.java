class Move {
    Location loc;
    Direction dir;

    Move(Location loc_, Direction dir_) {
        loc = loc_;
        dir = dir_;
    }
}
