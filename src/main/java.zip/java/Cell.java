class Cell {
    int owner, strength, production, x, y;
    boolean mine = false;

    Cell(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
