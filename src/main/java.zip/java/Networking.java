import java.util.ArrayList;

class Networking {
    private static int _width, _height;
    private static ArrayList< ArrayList<Integer> > _productions;

    private static void deserializeGameMapSize(String inputString) {
        String[] inputStringComponents = inputString.split(" ");

        _width = Integer.parseInt(inputStringComponents[0]);
        _height = Integer.parseInt(inputStringComponents[1]);
    }


    private static void deserializeProductions(String inputString) {
        String[] inputStringComponents = inputString.split(" ");

        int index = 0;
        _productions = new ArrayList<>();
        for(int a = 0; a < _height; a++) {
            ArrayList<Integer> row = new ArrayList<>();
            for(int b = 0; b < _width; b++) {
                row.add(Integer.parseInt(inputStringComponents[index]));
                index++;
            }
            _productions.add(row);
        }
    }

    private static String serializeMoveList(ArrayList<Move> moves) {
        StringBuilder builder = new StringBuilder();
        for(Move move : moves) builder.append(move.loc.x).append(" ").append(move.loc.y).append(" ").append(move.dir.ordinal()).append(" ");
        return builder.toString();
    }

    private static GameMap deserializeGameMap(String inputString, int myID) {
        String[] inputStringComponents = inputString.split(" ");

        GameMap map = new GameMap(_width, _height);

        // Run-length encode of owners
        int y = 0, x = 0;
        int counter, owner;
        int currentIndex = 0;
        while(y != map.height) {
            counter = Integer.parseInt(inputStringComponents[currentIndex]);
            owner = Integer.parseInt(inputStringComponents[currentIndex + 1]);
            currentIndex += 2;
            for(int a = 0; a < counter; ++a) {
                map.contents.get(y).get(x).owner = owner;
                if (owner == myID) map.contents.get(y).get(x).mine = true;
                ++x;
                if(x == map.width) {
                    x = 0;
                    ++y;
                }
            }
        }

        for (int a = 0; a < map.contents.size(); ++a) {
            for (int b = 0; b < map.contents.get(a).size(); ++b) {
                int strengthInt = Integer.parseInt(inputStringComponents[currentIndex]);
                currentIndex++;
                map.contents.get(a).get(b).strength = strengthInt;
                map.contents.get(a).get(b).production = _productions.get(a).get(b);
            }
        }

        return map;
    }

    private static void sendString(String sendString) {
        System.out.print(sendString+'\n');
        System.out.flush();
    }

    private static String getString() {
        try {
            StringBuilder builder = new StringBuilder();
            int buffer;
            while ((buffer = System.in.read()) >= 0) {
                if (buffer == '\n') {
                    break;
                } else {
                    builder = builder.append((char)buffer);
                }
            }
	    if(builder.charAt(builder.length()-1) == '\r') builder.setLength(builder.length()-1); //Removes a carriage return if on windows for manual testing.
            return builder.toString();
        } catch(Exception e) {
            System.exit(1);
            return null; // the java compiler is stupid
        }
    }

    static InitPackage getInit() {
        InitPackage initPackage = new InitPackage();
        initPackage.myID = stringToInt(getString());
        deserializeGameMapSize(getString());
        deserializeProductions(getString());
        initPackage.map = deserializeGameMap(getString(), initPackage.myID);

        return initPackage;
    }

    private static int stringToInt(String value) {
        if (value == null) return 0;
        return Integer.parseInt(value);
    }

    static void sendInit(String name) {
        sendString(name);
    }

    static GameMap getFrame(int myID) {
        return deserializeGameMap(getString(), myID);
    }

    static void sendFrame(ArrayList<Move> moves) {
        sendString(serializeMoveList(moves));
    }

}
